<?php

session_start();

include('dbcon.php');

if(isset($_GET['campaign_id'])) {
    $campaign_id = $_GET['campaign_id'];
    // var_dump($campaign_id);
    // die();
    $searchQuery = "SELECT * FROM campaigns c, media_app ma, campaign_types ct WHERE c.campaign_type_id = ct.id AND c.media_app_id = ma.id AND c.id = '$campaign_id'";
    $searchResult = mysqli_query($connection, $searchQuery);
    $data = mysqli_fetch_array($searchResult);

    // var_dump($data);
    // die();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Campaign Details</title>
</head>
<body>
<section>
        <nav>
            <ul>
                <li><a href="#home">Home Page</a></li>
                <li><a href="#information">Information</a></li>
                <li><a href="#popular">Most Popular Social Media Apps</a></li>
                <li><a href="#parents">How Parents Can Help</a></li>
                <li><a href="#livestreaming">Livestreaming</a></li>
                <li><a href="#contact">Contact</a></li>
                <li><a href="#legislation">Legislation and Guidance</a></li>
            </ul>
        </nav>
    </section>

    <form action="details.php" method="GET">
        <h2>Social Media Campaign Details For <?php echo $data['name']; ?></h2>
        <img src="<?php echo $data['image_1']; ?>" />
        <img src="<?php echo $data['image_2']; ?>" />
        <img src="<?php echo $data['image_3']; ?>" />
        <img src="<?php echo $data['image_4']; ?>" />
    </form>
</body>
</html>